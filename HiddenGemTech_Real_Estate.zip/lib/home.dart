import 'package:flutter/material.dart';
import 'package:hiddengemrealestate/login.dart';
import 'package:hiddengemrealestate/home.dart';
import 'package:hiddengemrealestate/feed.dart';
import 'package:hiddengemrealestate/favorite.dart';
import 'package:hiddengemrealestate/myhome.dart';
import 'package:hiddengemrealestate/user.dart';

class FindHomes extends StatefulWidget {
  @override
  _FindHomesPageState createState() => _FindHomesPageState();
}

class _FindHomesPageState extends State<FindHomes> {
  String selectedButton = "Find Homes";
  TextEditingController searchController = TextEditingController();
  String? selectedDropdownValue;
  List<String> dropdownItems = [
    'Recommend',
    'Newest',
    'Distance',
    'Price (low to high)',
    'Price (high to low)',
    'Square Feet',
    'Lot size',
    'Price/sq ft'
  ];

  static const double cardWidth = 250;
  static const double cardHeight = 200;
  static const double buttonHeight = 30;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Redfin"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            _buildButtonRow(),
            SizedBox(height: 5),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildSearchRow(),
                _buildFilterButton("Filter"),
                SizedBox(width: 5),
                _buildSaveSearchButton("Save Search"),
              ],
            ),
            SizedBox(height: 480),
            _buildActionButtons(),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  'Sort By',
                  style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                _buildDropdown(),
              ],
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildHomesList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildButtonRow() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          ...["Find Homes", "Feed", "Favorites", "My Home", "My Redfin"]
              .map(_buildSlidingButton)
              .toList(),
        ],
      ),
    );
  }

  Widget _buildSlidingButton(String text) {
    bool isSelected = selectedButton == text;

    return GestureDetector(
      onTap: () => _onButtonTapped(text),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        margin: EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: isSelected ? Colors.red : Colors.transparent),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.red : Colors.black,
          ),
        ),
      ),
    );
  }

  void _onButtonTapped(String buttonText) {
    setState(() {
      selectedButton = buttonText;
    });
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => _getPageForButton(buttonText)),
    );
  }

  Widget _getPageForButton(String buttonText) {
    switch (buttonText) {
      case "Find Homes":
        return FindHomes();
      case "Feed":
        return Feed();
      case "Favorites":
        return Favorites();
      case "My Home":
        return MyHome();
      case "My Redfin":
        return MyRedfin();
      default:
        return Container();
    }
  }

  Widget _buildSearchRow() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 200,
            height: buttonHeight,
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Search',
                hintStyle:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                filled: true,
              ),
              style: TextStyle(fontSize: 10),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterButton(String title, [Color? color]) {
    return Container(
      width: 70,
      height: buttonHeight,
      child: ElevatedButton(
        onPressed: () {},
        child: Text(
          title,
          style: TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.bold,
            color: color == null
                ? const Color.fromARGB(255, 0, 0, 0)
                : Colors.white,
          ),
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor:
              color == null ? const Color.fromARGB(255, 0, 0, 0) : Colors.white,
          backgroundColor: color ?? const Color.fromARGB(255, 255, 255, 255),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }

  Widget _buildSaveSearchButton(String title, [Color? color]) {
    return Container(
      width: 80,
      height: buttonHeight,
      child: ElevatedButton(
        onPressed: () {},
        child: Text(
          title,
          style: TextStyle(
            fontSize: 5,
            fontWeight: FontWeight.bold,
            color: color == null
                ? const Color.fromARGB(255, 255, 255, 255)
                : const Color.fromARGB(255, 255, 255, 255),
          ),
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor:
              color == null ? const Color.fromARGB(255, 0, 0, 0) : Colors.white,
          backgroundColor: color ?? const Color.fromARGB(255, 255, 0, 0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8),
      child: DropdownButton<String>(
        value: selectedDropdownValue,
        hint: Text(
          'Recommended',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        items: dropdownItems.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(
              item,
            ),
          );
        }).toList(),
        onChanged: (String? newValue) {
          setState(() {
            selectedDropdownValue = newValue;
          });
        },
        style: TextStyle(color: Colors.black),
        isExpanded: false,
      ),
    );
  }

  Widget _buildActionButtons() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          _buildActionButton(
            'View',
            Icons.visibility,
            const Color.fromARGB(255, 0, 0, 0),
            const Color.fromARGB(255, 0, 0, 0),
            textSize: 8,
            iconSize: 8,
          ),
          SizedBox(
            width: 5,
          ),
          _buildActionButton(
            'Draw',
            Icons.draw,
            const Color.fromARGB(255, 0, 0, 0),
            const Color.fromARGB(255, 0, 0, 0),
            textSize: 8,
            iconSize: 8,
          ),
          SizedBox(
            width: 5,
          ),
          _buildActionButton(
            'Nearby',
            Icons.near_me,
            const Color.fromARGB(255, 0, 0, 0),
            const Color.fromARGB(255, 0, 0, 0),
            textSize: 8,
            iconSize: 8,
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(
      String text, IconData icon, Color textColor, Color iconColor,
      {double textSize = 8, double iconSize = 8}) {
    return SizedBox(
      height: 30,
      width: 90,
      child: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 255, 255, 255),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: iconColor, size: iconSize),
            SizedBox(width: 8),
            Text(
              text,
              style: TextStyle(
                color: textColor,
                fontSize: textSize,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHomesList() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Row(
        children: [
          _buildHomeCard(
              'assets/House/House_1.jpg',
              '\$524,000',
              '3 beds',
              '2 baths',
              '1,052 sq.ft.',
              '1308 Green Forest Dr #1, Austin, TX 78745',
              'Chris'),
          _buildHomeCard(
              'assets/House/House_2.jpg',
              '\$752,000',
              '4 beds',
              '3 baths',
              '1,125 sq.ft.',
              '1307 Green Forest Dr #1, Austin, TX 78745',
              'Sayaka'),
          _buildHomeCard(
              'assets/House/House_3.jpg',
              '\$457,000',
              '2 beds',
              '3 baths',
              '1,125 sq.ft.',
              '1306 Green Forest Dr #1, Austin, TX 78745',
              'Geoff'),
        ],
      ),
    );
  }

  Widget _buildHomeCard(String imagePath, String price, String beds,
      String baths, String size, String address, String listingProvider) {
    return Container(
      width: cardWidth,
      height: cardHeight,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            _buildImageSection(imagePath),
            _buildDetailsSection(
                price, beds, baths, size, address, listingProvider),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSection(String imagePath) {
    return Container(
      height: 80,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
        image: DecorationImage(image: AssetImage(imagePath), fit: BoxFit.cover),
      ),
      child: Align(
        alignment: Alignment.topLeft,
        child: Container(
          width: 90,
          height: 20,
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
              color: Colors.red, borderRadius: BorderRadius.circular(4)),
          child: Center(
            child: Text(
              'LISTED BY REDFIN',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 8,
                  fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailsSection(String price, String beds, String baths,
      String size, String address, String listingProvider) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(price,
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          SizedBox(height: 2),
          Row(
            children: [
              Text(beds, style: TextStyle(fontSize: 12)),
              SizedBox(width: 4),
              Text(baths, style: TextStyle(fontSize: 12)),
              SizedBox(width: 4),
              Text(size, style: TextStyle(fontSize: 12)),
            ],
          ),
          SizedBox(height: 4),
          Text(address,
              style: TextStyle(color: Colors.grey[600], fontSize: 12)),
          SizedBox(height: 4),
          Text('Listing provided by $listingProvider',
              style: TextStyle(color: Colors.grey[500], fontSize: 10)),
        ],
      ),
    );
  }
}

void main() => runApp(MaterialApp(home: FindHomes()));
