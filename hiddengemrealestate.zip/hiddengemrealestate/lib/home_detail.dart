import 'package:flutter/material.dart';
import 'package:hiddengemrealestate/login.dart';
import 'package:hiddengemrealestate/home.dart';
import 'package:hiddengemrealestate/home_detail.dart';
import 'package:hiddengemrealestate/feed.dart';
import 'package:hiddengemrealestate/favorite.dart';
import 'package:hiddengemrealestate/myhome.dart';
import 'package:hiddengemrealestate/user.dart';

class HomeDetail extends StatefulWidget {
  @override
  _HomeDetailPageState createState() => _HomeDetailPageState();
}

class _HomeDetailPageState extends State<HomeDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        flexibleSpace: Center(
          child: Image.asset(
            'assets/Misc/Redfin.png',
            fit: BoxFit.contain,
            height: 30,
          ),
        ),
        backgroundColor: Colors.red,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 8.0,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(
                  'assets/House/House_1.jpg',
                  fit: BoxFit.cover,
                  width: double.infinity,
                  height: 250,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
