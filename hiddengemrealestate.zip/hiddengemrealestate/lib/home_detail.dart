import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class HomeDetail extends StatefulWidget {
  final String imagePath;
  final String price;
  final String installmentPrice;
  final String beds;
  final String baths;
  final String size;
  final String address;
  final String listingProvider;
  final String aboutThisHome;

  HomeDetail({
    required this.imagePath,
    required this.price,
    required this.installmentPrice,
    required this.beds,
    required this.baths,
    required this.size,
    required this.address,
    required this.listingProvider,
    required this.aboutThisHome,
  });

  @override
  _HomeDetailState createState() => _HomeDetailState();
}

class _HomeDetailState extends State<HomeDetail> {
  bool _isExpanded = false;

  Widget _buildText(String text,
      {double fontSize = 14,
      FontWeight fontWeight = FontWeight.normal,
      Color? color}) {
    return Text(
      text,
      style:
          TextStyle(fontSize: fontSize, fontWeight: fontWeight, color: color),
    );
  }

  Widget _buildActionButton(
      IconData icon, String label, VoidCallback onPressed) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon, color: const Color.fromARGB(255, 255, 0, 0)),
          onPressed: onPressed,
        ),
        _buildText(label, fontSize: 12),
      ],
    );
  }

  Widget _buildListingDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildText(widget.price, fontSize: 24, fontWeight: FontWeight.bold),
        SizedBox(height: 8),
        _buildText('Installment: ${widget.installmentPrice} Per Month',
            fontSize: 16, color: Colors.grey[700]),
        SizedBox(height: 8),
        _buildText('${widget.beds} beds, ${widget.baths} baths, ${widget.size}',
            fontSize: 16),
        SizedBox(height: 8),
        _buildText(widget.address, fontSize: 14, color: Colors.grey[600]),
        SizedBox(height: 8),
        _buildText('Listing provided by ${widget.listingProvider}',
            fontSize: 12, color: Colors.grey[500]),
      ],
    );
  }

  Widget _buildAboutThisHome() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 16),
        _buildText('About This Home',
            fontSize: 18, fontWeight: FontWeight.bold),
        SizedBox(height: 8),
        _buildText(
          _isExpanded
              ? widget.aboutThisHome
              : widget.aboutThisHome.substring(0, 100) + '...',
          fontSize: 14,
          color: Colors.grey[700],
        ),
        TextButton(
          onPressed: () {
            setState(() {
              _isExpanded = !_isExpanded;
            });
          },
          style: TextButton.styleFrom(
            foregroundColor: const Color.fromARGB(255, 255, 0, 0),
          ),
          child: _buildText(
            _isExpanded ? 'Show less' : 'Continue reading',
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildIconTextRows() {
    String formattedDate = DateFormat('yMMMMd').format(DateTime.now());
    List<Map<String, dynamic>> items = [
      {'label': '2 hours on Redfin', 'icon': Icons.access_time},
      {'label': 'Single-family', 'icon': Icons.home},
      {'label': 'Built in $formattedDate', 'icon': Icons.build_outlined},
      {'label': 'Lorem ipsum', 'icon': Icons.fence},
      {'label': '2 Garage space', 'icon': Icons.car_rental},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ...items.map((item) {
          return Row(
            children: [
              Icon(item['icon'], color: Colors.red),
              SizedBox(width: 8),
              _buildText(item['label'], fontSize: 16),
              SizedBox(height: 10),
            ],
          );
        }).toList(),
        SizedBox(height: 5),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildText('Commutes', fontSize: 18, fontWeight: FontWeight.bold),
            TextButton(
              onPressed: () {},
              style: TextButton.styleFrom(
                foregroundColor: const Color.fromARGB(255, 255, 0, 0),
              ),
              child: _buildText('Add a commute',
                  fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        SizedBox(height: 5),
        _buildText(
          'Thinking of buying?',
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: const Color.fromARGB(255, 0, 0, 0),
        ),
      ],
    );
  }

  Widget _buildBox(
    String label1,
    String label2,
    String label3, {
    double boxWidth = 60.0,
    double boxHeight = 80.0,
    Color textColor = const Color.fromARGB(255, 0, 0, 0),
    FontWeight textWeight = FontWeight.normal,
  }) {
    return Container(
      width: boxWidth,
      height: boxHeight,
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        border: Border.all(color: textColor),
        borderRadius: BorderRadius.circular(8),
        color: Colors.white,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label1,
              style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
          SizedBox(height: 4),
          Text(label2,
              style: TextStyle(color: textColor, fontWeight: textWeight)),
          SizedBox(height: 4),
          Text(label3,
              style: TextStyle(color: textColor, fontWeight: textWeight)),
        ],
      ),
    );
  }

  Widget _buildBoxRow() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          _buildBox('Monday', '18', 'Nov',
              boxWidth: 100,
              boxHeight: 90,
              textColor: const Color.fromARGB(255, 0, 0, 0),
              textWeight: FontWeight.bold),
          SizedBox(width: 8),
          _buildBox('Tuesday', '19', 'Nov',
              boxWidth: 100,
              boxHeight: 90,
              textColor: const Color.fromARGB(255, 0, 0, 0),
              textWeight: FontWeight.bold),
          SizedBox(width: 8),
          _buildBox('Wednesday', '20', 'Nov',
              boxWidth: 100,
              boxHeight: 90,
              textColor: const Color.fromARGB(255, 0, 0, 0),
              textWeight: FontWeight.bold),
          SizedBox(width: 8),
          _buildBox('Thursday', '21', 'Nov',
              boxWidth: 100,
              boxHeight: 90,
              textColor: const Color.fromARGB(255, 0, 0, 0),
              textWeight: FontWeight.bold),
          SizedBox(width: 8),
          _buildBox('Friday', '22', 'Nov',
              boxWidth: 100,
              boxHeight: 90,
              textColor: const Color.fromARGB(255, 0, 0, 0),
              textWeight: FontWeight.bold),
          SizedBox(width: 8),
          _buildBox('Saturday', '23', 'Nov',
              boxWidth: 100,
              boxHeight: 90,
              textColor: const Color.fromARGB(255, 0, 0, 0),
              textWeight: FontWeight.bold),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        flexibleSpace: Center(
          child: Image.asset('assets/Misc/Redfin.png',
              fit: BoxFit.contain, height: 30),
        ),
        backgroundColor: Colors.red,
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.asset(widget.imagePath,
                    fit: BoxFit.cover, width: double.infinity, height: 200),
              ),
              SizedBox(height: 12),
              _buildListingDetails(),
              SizedBox(height: 5),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildActionButton(Icons.visibility_off, 'Hide', () {}),
                  _buildActionButton(Icons.favorite_border, 'Favorite', () {}),
                  _buildActionButton(Icons.share, 'Share', () {}),
                ],
              ),
              _buildAboutThisHome(),
              SizedBox(
                height: 5,
              ),
              _buildIconTextRows(),
              SizedBox(
                height: 10,
              ),
              _buildBoxRow(),
              SizedBox(
                height: 5,
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              decoration: BoxDecoration(
                border: Border.all(
                    color: const Color.fromARGB(255, 255, 0, 0), width: 1.5),
                borderRadius: BorderRadius.circular(100.0),
              ),
              child: IconButton(
                icon: Icon(Icons.help_outline,
                    size: 20.0, color: const Color.fromARGB(255, 255, 0, 0)),
                onPressed: () {},
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: const Color.fromARGB(255, 255, 0, 0),
                minimumSize: Size(150, 50),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Request Showing'),
                  SizedBox(height: 2),
                  _buildText('Next available: \$TimeOfDay', fontSize: 12),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
