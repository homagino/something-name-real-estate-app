import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class HomeDetail extends StatefulWidget {
  final String imagePath;
  final String price;
  final String installmentPrice;
  final String beds;
  final String baths;
  final String size;
  final String address;
  final String listingProvider;
  final String aboutThisHome;

  HomeDetail({
    required this.imagePath,
    required this.price,
    required this.installmentPrice,
    required this.beds,
    required this.baths,
    required this.size,
    required this.address,
    required this.listingProvider,
    required this.aboutThisHome,
  });

  @override
  _HomeDetailState createState() => _HomeDetailState();
}

String selectedButton = "Monday";
String selectedButton2 = "Tour in person";
String selectedButton3 = "Sale History";

class _HomeDetailState extends State<HomeDetail> {
  bool _isExpanded = false;
  final List<String> times = ['10am', '11am', '12pm', 'More'];

  Widget _buildText(String text,
      {double fontSize = 14,
      FontWeight fontWeight = FontWeight.normal,
      Color? color}) {
    return Text(
      text,
      style:
          TextStyle(fontSize: fontSize, fontWeight: fontWeight, color: color),
    );
  }

  Widget _buildActionButton(
      IconData icon, String label, VoidCallback onPressed) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon, color: const Color.fromARGB(255, 255, 0, 0)),
          onPressed: onPressed,
        ),
        _buildText(label, fontSize: 12),
      ],
    );
  }

  Widget _buildListingDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildText(widget.price, fontSize: 24, fontWeight: FontWeight.bold),
        SizedBox(height: 8),
        _buildText('Installment: ${widget.installmentPrice} Per Month',
            fontSize: 16, color: Colors.grey[700]),
        SizedBox(height: 8),
        _buildText('${widget.beds} beds, ${widget.baths} baths, ${widget.size}',
            fontSize: 16),
        SizedBox(height: 8),
        _buildText(widget.address, fontSize: 14, color: Colors.grey[600]),
        SizedBox(height: 8),
        _buildText('Listing provided by ${widget.listingProvider}',
            fontSize: 12, color: Colors.grey[500]),
      ],
    );
  }

  Widget _buildAboutThisHome() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 16),
        _buildText('About This Home',
            fontSize: 18, fontWeight: FontWeight.bold),
        SizedBox(height: 8),
        _buildText(
          _isExpanded
              ? widget.aboutThisHome
              : widget.aboutThisHome.substring(0, 100) + '...',
          fontSize: 14,
          color: Colors.grey[700],
        ),
        TextButton(
          onPressed: () {
            setState(() {
              _isExpanded = !_isExpanded;
            });
          },
          style: TextButton.styleFrom(
            foregroundColor: const Color.fromARGB(255, 255, 0, 0),
          ),
          child: _buildText(
            _isExpanded ? 'Show less' : 'Continue reading',
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildIconTextRows() {
    String formattedDate = DateFormat('yMMMMd').format(DateTime.now());
    List<Map<String, dynamic>> items = [
      {'label': '2 hours on Redfin', 'icon': Icons.access_time},
      {'label': 'Single-family', 'icon': Icons.home},
      {'label': 'Built in $formattedDate', 'icon': Icons.build_outlined},
      {'label': 'Lorem ipsum', 'icon': Icons.fence},
      {'label': '2 Garage space', 'icon': Icons.car_rental},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ...items.map((item) {
          return Row(
            children: [
              Icon(item['icon'], color: Colors.red),
              SizedBox(width: 8),
              _buildText(item['label'], fontSize: 16),
              SizedBox(height: 10),
            ],
          );
        }).toList(),
        SizedBox(height: 5),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildText('Commutes', fontSize: 18, fontWeight: FontWeight.bold),
            TextButton(
              onPressed: () {},
              style: TextButton.styleFrom(
                foregroundColor: const Color.fromARGB(255, 255, 0, 0),
              ),
              child: _buildText('Add a commute',
                  fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        SizedBox(height: 5),
        _buildText(
          'Thinking of buying?',
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: const Color.fromARGB(255, 0, 0, 0),
        ),
      ],
    );
  }

  Widget _buildDayButtonRow() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 255, 255, 255),
        borderRadius: BorderRadius.circular(20),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildDaySlidingButton("Monday", subtitle: "25 Nov"),
            _buildDaySlidingButton("Tuesday", subtitle: "26 Nov"),
            _buildDaySlidingButton("Wednesday", subtitle: "27 Nov"),
            _buildDaySlidingButton("Thursday", subtitle: "28 Nov"),
            _buildDaySlidingButton("Friday", subtitle: "29 Nov"),
            _buildDaySlidingButton("Saturday", subtitle: "30 Nov"),
            _buildDaySlidingButton("Sunday", subtitle: "1 Dec"),
          ],
        ),
      ),
    );
  }

  Widget _buildDaySlidingButton(String text, {String? subtitle}) {
    bool isSelected = selectedButton == text;

    return GestureDetector(
      onTap: () => _onButtonTapped(text),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        margin: EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: isSelected ? Colors.red : Colors.transparent),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              text,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: isSelected ? Colors.red : Colors.black,
              ),
            ),
            if (subtitle != null)
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: isSelected ? Colors.red : Colors.black,
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _onButtonTapped(String buttonText) {
    setState(() {
      selectedButton = buttonText;
    });
  }

  Widget _buildTourTypeButton() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 255, 255, 255),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center, // Center the Row
        children: [
          _buildTourSlidingButton("Tour in person"),
          _buildTourSlidingButton("Tour in video chat"),
        ],
      ),
    );
  }

  Widget _buildTourSlidingButton(String text2) {
    bool isSelected2 = selectedButton2 == text2;

    return GestureDetector(
      onTap: () => _onButtonTourTapped(text2),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        margin: EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected2 ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: isSelected2 ? Colors.red : Colors.transparent),
        ),
        child: Text(
          text2,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: isSelected2 ? Colors.red : Colors.black,
          ),
        ),
      ),
    );
  }

  void _onButtonTourTapped(String buttonText2) {
    setState(() {
      selectedButton2 = buttonText2;
    });
  }

  Widget _buildRequestShowing() {
    return Center(
      child: Container(
        width: 400,
        height: 60,
        child: ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: const Color.fromARGB(255, 255, 0, 0),
            padding: EdgeInsets.zero,
          ),
          child: Text(
            'Request showing',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStartOffer() {
    return Center(
      child: Container(
        width: 400,
        height: 60,
        child: OutlinedButton(
          onPressed: () {},
          style: OutlinedButton.styleFrom(
            foregroundColor: const Color.fromARGB(255, 0, 0, 0),
            side: BorderSide(
              color: const Color.fromARGB(255, 0, 0, 0),
              width: 1,
            ),
            padding: EdgeInsets.zero,
            backgroundColor: const Color.fromARGB(255, 255, 255, 255),
          ),
          child: Text(
            'Start an offer',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildUpcoming() {
    int? _selectedOption;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 16),
        _buildText('Upcoming open houses',
            fontSize: 18, fontWeight: FontWeight.bold),
        SizedBox(height: 8),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.calendar_today,
              size: 24,
              color: Colors.black,
            ),
            SizedBox(width: 4),
            Text(
              'No upcoming open houses',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        Column(
          children: [
            Row(
              children: [
                Radio<int>(
                  value: 1,
                  groupValue: _selectedOption,
                  onChanged: (int? value) {
                    _selectedOption = value;
                  },
                ),
                GestureDetector(
                  onTap: () {
                    _selectedOption = 1;
                  },
                  child: Text('Tour in person'),
                ),
              ],
            ),
            Row(
              children: [
                Radio<int>(
                  value: 2,
                  groupValue: _selectedOption,
                  onChanged: (int? value) {
                    _selectedOption = value;
                  },
                ),
                GestureDetector(
                  onTap: () {
                    _selectedOption = 2;
                  },
                  child: Text('Tour via video chat'),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTimeButton() {
    return Row(
      children: [
        Text('Today :', style: TextStyle(fontSize: 16)),
        SizedBox(width: 8),
        TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
            foregroundColor: const Color.fromARGB(255, 255, 0, 0),
          ),
          child: Text('10 AM', style: TextStyle(fontSize: 16)),
        ),
        SizedBox(width: 3),
        TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
            foregroundColor: Color.fromARGB(255, 255, 0, 0),
          ),
          child: Text('11 AM', style: TextStyle(fontSize: 16)),
        ),
        SizedBox(width: 3),
        TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
            foregroundColor: Color.fromARGB(255, 255, 0, 0),
          ),
          child: Text('12 PM', style: TextStyle(fontSize: 16)),
        ),
        SizedBox(width: 3),
        TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
            foregroundColor: Color.fromARGB(255, 255, 0, 0),
          ),
          child: Text('More', style: TextStyle(fontSize: 16)),
        ),
      ],
    );
  }

  Widget _buildInstallmentGraph() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '${widget.installmentPrice} Per Month',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            TextButton(
              onPressed: () {},
              child: Text(
                'Reset',
                style: TextStyle(
                    fontSize: 12, color: const Color.fromARGB(255, 255, 0, 0)),
              ),
            ),
          ],
        ),
        SizedBox(height: 16),
        // Progress Bar
        Container(
          height: 20,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.grey[300],
          ),
          child: Row(
            children: [
              Flexible(
                flex: 2787,
                child: Container(color: Colors.cyan),
              ),
              Flexible(
                flex: 866,
                child: Container(color: Colors.blue),
              ),
              Flexible(
                flex: 67,
                child: Container(color: Colors.red),
              ),
              Flexible(
                flex: 389,
                child: Container(color: Colors.yellow),
              ),
            ],
          ),
        ),
        SizedBox(height: 20),
        // Breakdown Details
        Column(
          children: [
            _buildDetailRow(Colors.cyan, 'Principal and interest', '\$2,787'),
            _buildDetailRow(Colors.blue, 'Property taxes', '\$866'),
            _buildDetailRow(Colors.red, 'HOA dues', '\$67'),
            _buildDetailRow(Colors.yellow, "Homeowners'" "insurance", '\$389'),
          ],
        ),
      ],
    );
  }

  Widget _buildDetailRow(Color color, String label, String amount) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              label,
              style: TextStyle(fontSize: 16),
            ),
          ),
          Text(
            amount,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildAdvanceOption() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildBox('Home price', '\$530,000', icon: Icons.edit),
            _buildBox('Down payment', '20%', icon: Icons.edit), // Add icon here
          ],
        ),
        SizedBox(
          height: 8,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildBox('Loan type', '30-Year Fixed', icon: Icons.edit),
            _buildBox('Interest rate', '6.879%', icon: Icons.edit),
          ],
        ),
      ],
    );
  }

  Widget _buildBox(String text1, String text2, {IconData? icon}) {
    return Container(
      width: 170,
      height: 70,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 255, 0, 0),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            text1,
            style: TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                text2,
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
              if (icon != null) ...[
                SizedBox(width: 4), // Optional spacing between text and icon
                Icon(icon,
                    size: 16,
                    color: Colors.white), // Adjust the size and color as needed
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAdvanceOptionTextButton() {
    return Center(
      child: Container(
        width: 400,
        height: 60,
        child: TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
            foregroundColor: const Color.fromARGB(255, 255, 0, 0),
            padding: EdgeInsets.zero,
          ),
          child: Text(
            'Advanced option',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPre() {
    return Center(
      child: Container(
        width: 400,
        height: 60,
        child: OutlinedButton(
          onPressed: () {},
          style: OutlinedButton.styleFrom(
            foregroundColor: const Color.fromARGB(255, 0, 0, 0),
            side: BorderSide(
              color: const Color.fromARGB(255, 0, 0, 0),
              width: 1,
            ),
            padding: EdgeInsets.zero,
            backgroundColor: const Color.fromARGB(255, 255, 255, 255),
          ),
          child: Text(
            'Get pre-approved',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSellerSection() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ask a question',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 0, 0, 0),
              ),
            ),
            SizedBox(height: 8),
            ClipOval(
              child: Image.asset(
                'assets/Misc/Woramet.jpg',
                width: 140,
                height: 140,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 8),
            _buildText('Seller Name: Woramet Worasaen',
                fontSize: 16, fontWeight: FontWeight.bold),
            SizedBox(height: 4),
            _buildText('Seller Company: TeamTrenThai',
                fontSize: 14, color: Colors.grey[600]),
            SizedBox(height: 4),
            _buildText('Contact: 084-321-3325',
                fontSize: 14, color: Colors.grey[600]),
          ],
        ),
        SizedBox(width: 16),
      ],
    );
  }

  Widget _buildMessageBox() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 100,
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              border: Border.all(color: const Color.fromARGB(255, 0, 0, 0)),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextField(
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Type your message here...',
                border: InputBorder.none,
              ),
            ),
          ),
        ),
        SizedBox(width: 8),
        ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: const Color.fromARGB(255, 255, 0, 0),
          ),
          child: Text('Send'),
        ),
      ],
    );
  }

  Widget _buildSaleTaxHistoryButton() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 255, 255, 255),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildSaleTaxHistorySlidingButton("Sale History"),
          _buildSaleTaxHistorySlidingButton("Tax History"),
        ],
      ),
    );
  }

  Widget _buildSaleTaxHistorySlidingButton(String text3) {
    bool isSelected3 = selectedButton3 == text3;

    return GestureDetector(
      onTap: () => _onButtonSaleTaxHistoryTapped(text3),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        margin: EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected3 ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: isSelected3 ? Colors.red : Colors.transparent),
        ),
        child: Text(
          text3,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: isSelected3 ? Colors.red : Colors.black,
          ),
        ),
      ),
    );
  }

  void _onButtonSaleTaxHistoryTapped(String buttonText3) {
    setState(() {
      selectedButton3 = buttonText3;
    });
  }

  Widget _buildNotifyPriceTextButton() {
    return Container(
      width: 300,
      height: 40,
      alignment: Alignment.centerLeft,
      child: TextButton(
        onPressed: () {},
        style: TextButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 255, 0, 0),
          padding: EdgeInsets.zero,
        ),
        child: Text(
          'Notify me when the price changes.',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildSaleTaxHistoryList() {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildHistoryEntry("Nov 18, 2024", "Listed (New)", "\$530,000"),
          Divider(),
          _buildHistoryEntry("Oct 20, 2024", "Listing Removed", "-"),
          Divider(),
          _buildHistoryEntry("Oct 13, 2024", "Price Changed", "\$457,000"),
          Divider(),
          _buildHistoryEntry("Oct 9, 2024", "Price Changed", "\$423,000"),
          Divider(),
          _buildHistoryEntry("Oct 3, 2024", "Listing (New)", "\$396,000"),
          Divider(),
          _buildHistoryEntry("Oct 1, 2024", "Listing Removed", "-"),
        ],
      ),
    );
  }

  Widget _buildHistoryEntry(String date, String title, String details) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 2,
          child: Text(
            date,
            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
          ),
        ),
        Expanded(
          flex: 4,
          child: Text(
            title,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ),
        Expanded(
          flex: 2,
          child: Text(
            details,
            textAlign: TextAlign.right,
            style: TextStyle(fontSize: 16, color: Colors.black),
          ),
        ),
      ],
    );
  }

// Manage Widget Position
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        flexibleSpace: Center(
          child: Image.asset('assets/Misc/Redfin.png',
              fit: BoxFit.contain, height: 30),
        ),
        backgroundColor: Colors.red,
      ),
      backgroundColor: const Color.fromARGB(255, 253, 253, 253),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.asset(widget.imagePath,
                    fit: BoxFit.cover, width: double.infinity, height: 200),
              ),
              SizedBox(height: 12),
              _buildListingDetails(),
              SizedBox(height: 5),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildActionButton(Icons.visibility_off, 'Hide', () {}),
                  _buildActionButton(Icons.favorite_border, 'Favorite', () {}),
                  _buildActionButton(Icons.share, 'Share', () {}),
                ],
              ),
              _buildAboutThisHome(),
              SizedBox(
                height: 5,
              ),
              _buildIconTextRows(),
              SizedBox(
                height: 10,
              ),
              _buildDayButtonRow(),
              SizedBox(
                height: 10,
              ),
              _buildTourTypeButton(),
              SizedBox(
                height: 10,
              ),
              _buildRequestShowing(),
              SizedBox(
                height: 10,
              ),
              _buildStartOffer(),
              SizedBox(
                height: 10,
              ),
              _buildUpcoming(),
              SizedBox(
                height: 5,
              ),
              _buildTimeButton(),
              SizedBox(
                height: 5,
              ),
              _buildInstallmentGraph(),
              SizedBox(
                height: 10,
              ),
              _buildAdvanceOption(),
              SizedBox(
                height: 8,
              ),
              _buildAdvanceOptionTextButton(),
              SizedBox(
                height: 8,
              ),
              _buildPre(),
              SizedBox(
                height: 12,
              ),
              _buildSellerSection(),
              SizedBox(
                height: 8,
              ),
              _buildMessageBox(),
              SizedBox(
                height: 8,
              ),
              _buildSaleTaxHistoryButton(),
              SizedBox(
                height: 8,
              ),
              _buildNotifyPriceTextButton(),
              SizedBox(
                height: 8,
              ),
              _buildSaleTaxHistoryList(),
              SizedBox(
                height: 8,
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              decoration: BoxDecoration(
                border: Border.all(
                    color: const Color.fromARGB(255, 255, 0, 0), width: 1.5),
                borderRadius: BorderRadius.circular(100.0),
              ),
              child: IconButton(
                icon: Icon(Icons.help_outline,
                    size: 20.0, color: const Color.fromARGB(255, 255, 0, 0)),
                onPressed: () {},
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: const Color.fromARGB(255, 255, 0, 0),
                minimumSize: Size(150, 50),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Request Showing'),
                  SizedBox(height: 2),
                  _buildText('Next available: \$TimeOfDay', fontSize: 12),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
