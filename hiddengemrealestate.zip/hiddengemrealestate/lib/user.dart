import 'package:flutter/material.dart';
import 'package:hiddengemrealestate/login.dart';
import 'package:hiddengemrealestate/home.dart';
import 'package:hiddengemrealestate/feed.dart';
import 'package:hiddengemrealestate/favorite.dart';
import 'package:hiddengemrealestate/myhome.dart';
import 'package:hiddengemrealestate/user.dart';

class MyRedfin extends StatefulWidget {
  @override
  _MyRedfinPageState createState() => _MyRedfinPageState();
}

class _MyRedfinPageState extends State<MyRedfin> {
  String selectedButton = "My Redfin";
  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Redfin"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildSlidingButton("Find Homes"),
                  _buildSlidingButton("Feed"),
                  _buildSlidingButton("Favorites"),
                  _buildSlidingButton("My Home"),
                  _buildSlidingButton("My Redfin"),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Stack(
              children: [
                SizedBox(
                  height: 20,
                ),
                Center(
                  child: Column(
                    mainAxisSize:
                        MainAxisSize.min, // Use min size to fit the content
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(150),
                        child: Image.asset(
                          'assets/Misc/UserProfilePhoto.jpg',
                          width: 150,
                          height: 150,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Sanatthapoom Vitthayapaisal',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
            SizedBox(height: 10),
            Container(
              width: 250,
              height: 50,
              child: ElevatedButton(
                onPressed: () {},
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.visibility,
                      size: 16,
                      color: Colors.white,
                    ),
                    SizedBox(width: 4),
                    Text(
                      'Recently Viewed',
                      style: TextStyle(
                        fontSize: 9,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: const Color.fromARGB(255, 255, 0, 0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSlidingButton(String text) {
    bool isSelected = selectedButton == text;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedButton = text;
        });

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => _getPageForButton(text),
          ),
        );
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        margin: EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: isSelected ? Colors.red : Colors.transparent),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.red : Colors.black,
          ),
        ),
      ),
    );
  }

  Widget _getPageForButton(String buttonText) {
    switch (buttonText) {
      case "Find Homes":
        return FindHomes();
      case "Feed":
        return Feed();
      case "Favorites":
        return Favorites();
      case "My Home":
        return MyHome();
      case "My Redfin":
        return MyRedfin();
      default:
        return Container();
    }
  }
}
