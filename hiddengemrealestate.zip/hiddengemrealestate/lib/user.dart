import 'package:flutter/material.dart';
import 'package:hiddengemrealestate/login.dart';
import 'package:hiddengemrealestate/home.dart';
import 'package:hiddengemrealestate/feed.dart';
import 'package:hiddengemrealestate/favorite.dart';
import 'package:hiddengemrealestate/myhome.dart';
import 'package:hiddengemrealestate/user.dart';

class MyRedfin extends StatefulWidget {
  @override
  _MyRedfinPageState createState() => _MyRedfinPageState();
}

class _MyRedfinPageState extends State<MyRedfin> {
  String selectedButton = "My Redfin";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        flexibleSpace: Center(
          child: Image.asset(
            'assets/Misc/Redfin.png',
            fit: BoxFit.contain,
            height: 30,
          ),
        ),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 10),
            _buildButtonRow(),
            SizedBox(height: 10),
            _buildProfile(),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'My home search',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(height: 10),
            _buildRecentlyViewedButton(),
            SizedBox(height: 5),
            _buildSavedSearchesButton(),
            SizedBox(height: 5),
            _buildOpenHousesButton(),
            SizedBox(height: 5),
            _buildPastToursButton(),
            SizedBox(height: 5),
            _buildOffersButton(),
            SizedBox(height: 5),
            _buildPremierUserButton(),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Finances',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(height: 10),
            _buildPaymentCalcButton(),
            SizedBox(height: 5),
            _buildAffordButton(),
            SizedBox(height: 5),
            _buildCompareButton(),
            SizedBox(height: 5),
          ],
        ),
      ),
    );
  }

  Widget _buildButtonRow() {
    const buttonLabels = [
      "Find Homes",
      "Feed",
      "Favorites",
      "My Home",
      "My Redfin"
    ];
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: buttonLabels.map(_buildSlidingButton).toList(),
      ),
    );
  }

  Widget _buildSlidingButton(String text) {
    bool isSelected = selectedButton == text;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedButton = text;
        });
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => _getPageForButton(text)),
        );
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        margin: EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: isSelected ? Colors.red : Colors.transparent),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.red : Colors.black,
          ),
        ),
      ),
    );
  }

  Widget _buildProfile() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(150),
          child: Image.asset(
            'assets/Misc/UserProfilePhoto.jpg',
            width: 150,
            height: 150,
            fit: BoxFit.cover,
          ),
        ),
        SizedBox(height: 10),
        Text(
          'Sanatthapoom Vitthayapaisal',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget _buildRecentlyViewedButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.visibility,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('Recently Viewed',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildSavedSearchesButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.search,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('Saved Searches',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildOpenHousesButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.house,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('Open Houses',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildPastToursButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.calendar_month,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('Past Tours',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildOffersButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.article,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('Offers',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildPremierUserButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.diamond,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('Redfin Premier',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildPaymentCalcButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.wallet,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('Monthly Payment Calculator',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildAffordButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.calculate,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('How much can i afford?',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildCompareButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.percent,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 4),
            Text('Compare mortgage rates',
                style: TextStyle(
                    fontSize: 9,
                    color: const Color.fromARGB(255, 0, 0, 0),
                    fontWeight: FontWeight.bold)),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _getPageForButton(String buttonText) {
    switch (buttonText) {
      case "Find Homes":
        return FindHomes();
      case "Feed":
        return Feed();
      case "Favorites":
        return Favorites();
      case "My Home":
        return MyHome();
      case "My Redfin":
        return MyRedfin();
      default:
        return Container();
    }
  }
}
