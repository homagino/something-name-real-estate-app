import 'package:flutter/material.dart';
import 'package:hiddengemrealestate/home.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  void _loginWithEmail() {
    if (_formKey.currentState!.validate()) {
      // Perform login action (for example: call API or navigate to next page)
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Logging in with Email')),
      );
    }
  }

  void _loginWithFacebook() {
    // Simulate login with Facebook
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Logging in with Facebook')),
    );
  }

  void _loginWithGoogle() {
    // Simulate login with Google
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Logging in with Google')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            const SizedBox(height: 10),
            Text(
              'Join or sign in to unlock',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold, // Make the first line bold
              ),
            ),
            Text(
              'the full experience',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold, // Make the second line bold
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(labelText: 'E-mail'),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an e-mail';
                  }
                  if (!RegExp(
                          r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
                      .hasMatch(value)) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 255, 255, 255),
                  foregroundColor: const Color.fromARGB(255, 0, 0, 0),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(width: 8),
                    Text('Continue with Email'),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'or',
                style: TextStyle(
                  fontSize: 16, // Adjust the font size as needed
                  fontWeight: FontWeight.bold, // Optional: make the text bold
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: _loginWithGoogle,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[800],
                  foregroundColor: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Image(
                      image: AssetImage('assets/ICON/GOOGLE_ICON.png'),
                      width: 20,
                      height: 20,
                    ),
                    SizedBox(width: 8),
                    Text('Login with Google'),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: _loginWithFacebook,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Image(
                      image: AssetImage('assets/ICON/FB_ICON.png'),
                      width: 20,
                      height: 20,
                    ),
                    SizedBox(width: 8),
                    Text('Login with Facebook'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
