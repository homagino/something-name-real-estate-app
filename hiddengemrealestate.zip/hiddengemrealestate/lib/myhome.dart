import 'package:flutter/material.dart';
import 'package:hiddengemrealestate/home.dart';
import 'package:hiddengemrealestate/feed.dart';
import 'package:hiddengemrealestate/favorite.dart';
import 'package:hiddengemrealestate/user.dart';

class MyHome extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHome> {
  String selectedButton = "My Home";
  TextEditingController searchController = TextEditingController();
  static const double buttonHeight = 30, buttonWidth = 395;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        flexibleSpace: Center(
          child: Image.asset(
            'assets/Misc/Redfin.png',
            fit: BoxFit.contain,
            height: 30,
          ),
        ),
        backgroundColor: Colors.red,
      ),
      backgroundColor: const Color.fromARGB(255, 253, 253, 253),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 10),
            _buildButtonRow(),
            SizedBox(height: 250),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      'Do you own a home?',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Track your home's estimate and nearby sales",
                      style: TextStyle(fontSize: 10),
                    ),
                  ),
                ),
                SizedBox(height: 5),
                _buildAddressRow(),
                SizedBox(height: 5),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildButtonRow() {
    const buttonLabels = [
      "Find Homes",
      "Feed",
      "Favorites",
      "My Home",
      "My Redfin"
    ];
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: buttonLabels.map(_buildSlidingButton).toList(),
      ),
    );
  }

  Widget _buildSlidingButton(String text) {
    bool isSelected = selectedButton == text;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedButton = text;
        });
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => _getPageForButton(text)),
        );
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        margin: EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: isSelected ? Colors.red : Colors.transparent),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.red : Colors.black,
          ),
        ),
      ),
    );
  }

  Widget _buildAddressRow() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: buttonWidth,
            height: buttonHeight,
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Enter your address',
                hintStyle:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                filled: true,
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
              style: TextStyle(fontSize: 10),
            ),
          ),
        ],
      ),
    );
  }

  Widget _getPageForButton(String buttonText) {
    switch (buttonText) {
      case "Find Homes":
        return FindHomes();
      case "Feed":
        return Feed();
      case "Favorites":
        return Favorites();
      case "My Home":
        return MyHome();
      case "My Redfin":
        return MyRedfin();
      default:
        return Container();
    }
  }
}
