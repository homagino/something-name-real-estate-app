import 'package:flutter/material.dart';
import 'package:hiddengemrealestate/home.dart';
import 'package:hiddengemrealestate/favorite.dart';
import 'package:hiddengemrealestate/myhome.dart';
import 'package:hiddengemrealestate/user.dart';

class Feed extends StatefulWidget {
  @override
  _FeedPageState createState() => _FeedPageState();
}

class _FeedPageState extends State<Feed> {
  String selectedButton = "Feed";

  static const double cardWidth = 400;
  static const double cardHeight = 225;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        flexibleSpace: Center(
          child: Image.asset(
            'assets/Misc/Redfin.png',
            fit: BoxFit.contain,
            height: 30,
          ),
        ),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 10),
            _buildButtonRow(),
            SizedBox(height: 10),
            _buildYourSavedButton(),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Previous Updates',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(height: 5),
            Expanded(
              child: ListView(
                children: [
                  _buildHomesList(),
                ],
              ),
            ),
            SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Widget _buildButtonRow() {
    const buttonLabels = [
      "Find Homes",
      "Feed",
      "Favorites",
      "My Home",
      "My Redfin"
    ];
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: buttonLabels.map(_buildSlidingButton).toList(),
      ),
    );
  }

  Widget _buildSlidingButton(String text) {
    bool isSelected = selectedButton == text;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedButton = text;
        });
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => _getPageForButton(text)),
        );
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        margin: EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: isSelected ? Colors.red : Colors.transparent),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.red : Colors.black,
          ),
        ),
      ),
    );
  }

  Widget _buildYourSavedButton() {
    return Container(
      width: 380,
      height: 50,
      child: ElevatedButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.search,
                size: 16, color: const Color.fromARGB(255, 0, 0, 0)),
            SizedBox(width: 6),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 12),
                Text('Create your first saved search',
                    style: TextStyle(
                        fontSize: 9,
                        color: const Color.fromARGB(255, 0, 0, 0),
                        fontWeight: FontWeight.bold)),
                SizedBox(height: 2),
                Text('Get personalized home updates',
                    style: TextStyle(
                        fontSize: 8,
                        color: const Color.fromARGB(255, 100, 100, 100),
                        fontWeight: FontWeight.normal)),
              ],
            ),
          ],
        ),
        style: ElevatedButton.styleFrom(
          foregroundColor: const Color.fromARGB(255, 0, 0, 0),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _buildHomesList() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        children: [
          _buildHomeCard(
              'assets/House/House_1.jpg',
              '\$524,000',
              '3 beds',
              '2 baths',
              '1,052 sq.ft.',
              '1308 Green Forest Dr #1, Austin, TX 78745',
              'Chris'),
          _buildHomeCard(
              'assets/House/House_2.jpg',
              '\$752,000',
              '4 beds',
              '3 baths',
              '1,125 sq.ft.',
              '1307 Green Forest Dr #1, Austin, TX 78745',
              'Sayaka'),
          _buildHomeCard(
              'assets/House/House_3.jpg',
              '\$457,000',
              '2 beds',
              '3 baths',
              '1,125 sq.ft.',
              '1306 Green Forest Dr #1, Austin, TX 78745',
              'Geoff'),
          _buildHomeCard(
              'assets/House/House_1.jpg',
              '\$524,000',
              '3 beds',
              '2 baths',
              '1,052 sq.ft.',
              '1308 Green Forest Dr #1, Austin, TX 78745',
              'Chris'),
          _buildHomeCard(
              'assets/House/House_2.jpg',
              '\$752,000',
              '4 beds',
              '3 baths',
              '1,125 sq.ft.',
              '1307 Green Forest Dr #1, Austin, TX 78745',
              'Sayaka'),
          _buildHomeCard(
              'assets/House/House_3.jpg',
              '\$457,000',
              '2 beds',
              '3 baths',
              '1,125 sq.ft.',
              '1306 Green Forest Dr #1, Austin, TX 78745',
              'Geoff'),
        ],
      ),
    );
  }

  Widget _buildHomeCard(String imagePath, String price, String beds,
      String baths, String size, String address, String listingProvider) {
    return Container(
      width: cardWidth,
      height: cardHeight,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            _buildImageSection(imagePath),
            _buildDetailsSection(
                price, beds, baths, size, address, listingProvider),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSection(String imagePath) {
    return Container(
      height: 120,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
        image: DecorationImage(image: AssetImage(imagePath), fit: BoxFit.cover),
      ),
      child: Align(
        alignment: Alignment.bottomRight,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              GestureDetector(
                onTap: () {},
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.location_on,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 8),
              GestureDetector(
                onTap: () {},
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.share,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 8),
              GestureDetector(
                onTap: () {},
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.favorite_border,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailsSection(String price, String beds, String baths,
      String size, String address, String listingProvider) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(price,
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          SizedBox(height: 2),
          Row(
            children: [
              Text(beds, style: TextStyle(fontSize: 12)),
              SizedBox(width: 4),
              Text(baths, style: TextStyle(fontSize: 12)),
              SizedBox(width: 4),
              Text(size, style: TextStyle(fontSize: 12)),
            ],
          ),
          SizedBox(height: 4),
          Text(address,
              style: TextStyle(color: Colors.grey[600], fontSize: 12)),
          SizedBox(height: 4),
          Text('Listing provided by $listingProvider',
              style: TextStyle(color: Colors.grey[500], fontSize: 10)),
        ],
      ),
    );
  }

  Widget _getPageForButton(String buttonText) {
    switch (buttonText) {
      case "Find Homes":
        return FindHomes();
      case "Feed":
        return Feed();
      case "Favorites":
        return Favorites();
      case "My Home":
        return MyHome();
      case "My Redfin":
        return MyRedfin();
      default:
        return Container();
    }
  }
}
