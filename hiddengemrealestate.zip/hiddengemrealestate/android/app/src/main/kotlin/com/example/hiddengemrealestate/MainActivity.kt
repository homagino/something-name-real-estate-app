package com.example.hiddengemrealestate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
